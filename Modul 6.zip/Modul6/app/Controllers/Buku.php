<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\BukuModel;
use CodeIgniter\Validation\Exceptions\ValidationException;
class Buku extends BaseController
{
    protected $bukuModel;

    public function __construct()
    {
        $this->bukuModel = new BukuModel();
    }
    public function index()
    {
        $data['buku'] = $this->bukuModel->findAll();
        return view('index', $data);
    }
    public function create()
    {
        return view('create');
    }
    public function store()
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'judul' => [
                'label' => 'Judul',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'penulis' => [
                'label' => 'Penulis',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'penerbit' => [
                'label' => 'Penerbit',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'tahun_terbit' => [
                'label' => 'Tahun Terbit',
                'rules' => 'required|numeric|greater_than[1800]|less_than[2024]',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'numeric' => '{field} harus berupa angka.',
                    'greater_than' => '{field} harus lebih besar dari 1800.',
                    'less_than' => '{field} harus kurang dari 2024.'
                ]
            ]
        ]);
        if (!$validation->withRequest($this->request)->run()) {
            return view('create', ['validation' => $validation]);
        }
        $tahunTerbit = $this->request->getPost('tahun_terbit');
        if ($tahunTerbit > date('Y')) {
            $validation->setError('tahun_terbit', 'Tahun Terbit harus lebih kecil dari tahun saat ini.');
            throw new ValidationException($validation);
        }
        $data = [
            'judul' => $this->request->getPost('judul'),
            'penulis' => $this->request->getPost('penulis'),
            'penerbit' => $this->request->getPost('penerbit'),
            'tahun_terbit' => $tahunTerbit,
        ];
        $this->bukuModel->save($data);
        return redirect()->to('/dashboard');
    }
    public function edit($id)
    {
        $data['buku'] = $this->bukuModel->find($id);
        if (!$data['buku']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Buku dengan ID ' . $id . ' tidak ditemukan.');
        }
        return view('edit', $data);
    }
    public function update($id)
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'judul' => [
                'label' => 'Judul',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'penulis' => [
                'label' => 'Penulis',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'penerbit' => [
                'label' => 'Penerbit',
                'rules' => 'required|string',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'string' => '{field} harus berupa string.'
                ]
            ],
            'tahun_terbit' => [
                'label' => 'Tahun Terbit',
                'rules' => 'required|numeric|greater_than[1800]|less_than[2024]',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'numeric' => '{field} harus berupa angka.',
                    'greater_than' => '{field} harus lebih besar dari 1800.',
                    'less_than' => '{field} harus kurang dari 2024.'
                ]
            ]
        ]);
        if (!$validation->withRequest($this->request)->run()) {
            return view('edit', ['validation' => $validation, 'buku' => $this->bukuModel->find($id)]);
        }
        $tahunTerbit = $this->request->getPost('tahun_terbit');
        if ($tahunTerbit > date('Y')) {
            $validation->setError('tahun_terbit', 'Tahun Terbit harus lebih kecil dari tahun saat ini.');
            throw new ValidationException($validation);
        }
        $data = [
            'judul' => $this->request->getPost('judul'),
            'penulis' => $this->request->getPost('penulis'),
            'penerbit' => $this->request->getPost('penerbit'),
            'tahun_terbit' => $tahunTerbit,
        ];
        $this->bukuModel->update($id, $data);
        return redirect()->to('/dashboard');
    }
    public function delete($id)
    {
        $this->bukuModel->delete($id);
        return redirect()->to('/dashboard');
    }
}