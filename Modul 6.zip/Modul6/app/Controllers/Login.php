<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\UserModel;
class Login extends BaseController
{
    public function loginForm()
    {
        helper(['form']);
        return view('login');
    }
    public function login()
    {
        $session = session();
        $userModel = new UserModel();
        $identifier = $this->request->getVar('identifier'); 
        $password = $this->request->getVar('password');
        $data = $userModel->getUserByEmailOrUsername($identifier);
        if ($data) {
            if (password_verify($password, $data['password'])) {
                $session->set([
                    'user_id' => $data['id'],
                    'username' => $data['username'],
                    'logged_in' => true 
                ]);
                return redirect()->to('/dashboard');
            } else {
                $session->setFlashdata('msg', 'Password salah');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Username atau Email salah');
            return redirect()->to('/login');
        }
    }
    public function registerForm()
    {
        return view('register');
    }
    public function register()
    {}
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }
}