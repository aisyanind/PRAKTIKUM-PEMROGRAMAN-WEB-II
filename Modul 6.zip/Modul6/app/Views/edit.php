<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="edit">
    <div class="container register">
        <h1 class="register">Edit Buku</h1>
        <?php if(isset($validation)): ?>
            <div class="error register">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>
        <form class="register" action="<?= base_url('/buku/update/' . $buku['id']) ?>" method="post">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="judul">Judul:</label>
                <input type="text" name="judul" id="judul" class="input register" value="<?= $buku['judul'] ?>">
            </div>
            <div class="form-group">
                <label for="penulis">Penulis:</label>
                <input type="text" name="penulis" id="penulis" class="input register" value="<?= $buku['penulis'] ?>">
            </div>
            <div class="form-group">
                <label for="penerbit">Penerbit:</label>
                <input type="text" name="penerbit" id="penerbit" class="input register" value="<?= $buku['penerbit'] ?>">
            </div>
            <div class="form-group">
                <label for="tahun_terbit">Tahun Terbit:</label>
                <input type="text" name="tahun_terbit" id="tahun_terbit" class="input register" value="<?= $buku['tahun_terbit'] ?>">
            </div>
            <button type="submit" class="btn register">Update</button>
        </form>
        <p class="login-link register"><a href="<?= base_url('/dashboard') ?>">Kembali</a></p>
    </div>
</body>
</html>