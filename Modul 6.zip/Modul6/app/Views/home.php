<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nindy Gallery</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="login">
    <div class="header">
        <h2>Welcome to Nindy Gallery</h2>
        <div class="buttons">
            <a href="/login" class="btn btn-login">Login</a>
            <a href="/register" class="btn btn-register">Register</a>
        </div>
    </div>
    <div class="container">
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/1.JPG" alt="Book Image">
            <div class="title">HTML 5 Manual Book</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/2.JPG" alt="Book Image">
            <div class="title">Harry Potter and The Order of Phoenix</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/3.JPG" alt="Book Image">
            <div class="title">Think and Grow Rich</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/4.JPG" alt="Book Image">
            <div class="title">Strategic Leadership</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/5.JPG" alt="Book Image">
            <div class="title">Republik Naga (The Dragon Republic)</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/6.JPG" alt="Book Image">
            <div class="title">Kecerdasan Emosional</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/7.JPG" alt="Book Image">
            <div class="title">Pesan dari Luar Angkasa</div>
        </div>
        <div class="item">
            <img src="http://localhost/Modul6/app/Views/gambar/8.JPG" alt="Book Image">
            <div class="title">Home Sweet Loan</div>
        </div>
    </div>
</body>
</html>