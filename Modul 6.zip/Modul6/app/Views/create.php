<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Buku</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="create">
    <div class="container register">
        <h1 class="register">Create Buku</h1>
        <?php if(isset($validation)): ?>
            <div class="error register">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>
        <form class="register" action="<?= base_url('/buku/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="judul">Judul:</label>
                <input type="text" name="judul" id="judul" class="input register" value="<?= old('judul') ?>">
            </div>
            <div class="form-group">
                <label for="penulis">Penulis:</label>
                <input type="text" name="penulis" id="penulis" class="input register" value="<?= old('penulis') ?>">
            </div>
            <div class="form-group">
                <label for="penerbit">Penerbit:</label>
                <input type="text" name="penerbit" id="penerbit" class="input register" value="<?= old('penerbit') ?>">
            </div>
            <div class="form-group">
                <label for="tahun_terbit">Tahun Terbit:</label>
                <input type="number" name="tahun_terbit" id="tahun_terbit" class="input register" value="<?= old('tahun_terbit') ?>">
            </div>
            <button type="submit" class="btn register">Submit</button>
        </form>
    </div>
</body>
</html>