<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="login">
    <div class="container login">
        <h1 class="login">Login</h1>
        <?php if(session()->getFlashdata('msg')): ?>
            <div class="error login"><?= session()->getFlashdata('msg') ?></div>
        <?php endif; ?>
        <form action="/login" method="post" class="login">
            <input type="text" name="identifier" placeholder="Username or Email" required class="login">
            <input type="password" name="password" placeholder="Password" required class="login">
            <button type="submit" class="btn login">Login</button>
        </form>
        <div class="register-link login">
            <p>Don't have an account? <a href="/register">Register here</a></p>
        </div>
    </div>
</body>
</html>