<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="index">
    <h1 class="index">Daftar Buku</h1>
    <?php if(session()->getFlashdata('success')): ?>
        <p class="success index"><?= session()->getFlashdata('success') ?></p>
    <?php endif; ?>
    <table class="index">
        <thead>
            <tr class="index">
                <th class="index">Judul</th>
                <th class="index">Penulis</th>
                <th class="index">Penerbit</th>
                <th class="index">Tahun Terbit</th>
                <th class="index">Aksi</th>
            </tr>
        </thead>
        <tbody class="index">
            <?php if (!empty($buku)): ?>
                <?php foreach ($buku as $item): ?>
                <tr class="index">
                    <td class="index"><?= $item['judul'] ?></td>
                    <td class="index"><?= $item['penulis'] ?></td>
                    <td class="index"><?= $item['penerbit'] ?></td>
                    <td class="index"><?= $item['tahun_terbit'] ?></td>
                    <td class="action-links index">
                        <a class="index" href="<?= base_url('/buku/edit/'.$item['id']) ?>">Edit</a>
                        <a class="index" href="<?= base_url('/buku/delete/'.$item['id']) ?>">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr class="index">
                    <td class="index" colspan="5">Tidak ada data buku yang tersedia.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="<?= base_url('/buku/create') ?>" class="add-link index">Tambah Buku Baru</a>
    <p><a href="<?= base_url('/logout') ?>" class="logout-button index">Logout</a></p>
</body>
</html>