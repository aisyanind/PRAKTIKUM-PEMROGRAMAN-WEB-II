<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="http://localhost/Modul6/app/Views/styles.css">
</head>
<body class="register">
    <div class="container register">
        <h1 class="register">Register</h1>
        <form class="register" action="/register" method="post">
            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach (session()->getFlashdata('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach ?>
                    </ul>
                </div>
            <?php endif ?>
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <p><?= session()->getFlashdata('success') ?></p>
                </div>
            <?php endif ?>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" class="register" value="<?= old('username') ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" class="register" value="<?= old('email') ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" class="register" required>
            </div>
            <button type="submit" class="btn register">Register</button>
        </form>
        <div class="login-link register">
            Already have an account? <a href="/login" class="register">Login here</a>
        </div>
    </div>
</body>
</html>